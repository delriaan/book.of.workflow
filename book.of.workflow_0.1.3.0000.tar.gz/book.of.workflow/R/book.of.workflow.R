#' @title Book of Workflow
#
#' @description
#' `{pkg_title}` provides action-oriented functions that support data processing and connection workflows.
#'
#'
#' The following functional chapters are covered in \code{book.of.workflow}:\cr
#'
#' @section Chapter 1 - Environment Integrity: 
#' \itemize{
#' \item{\code{\link{?\%-=\%}}}
#' \item{\code{\link{?\%+=\%}}}
#' \item{\code{\link{?\%must.have\%}}}
#' \item{\code{\link{?check.env}}}
#' \item{\code{\link{?check_env_arg}}}
#' }
#'
#' @section Chapter 2 - Environment Processing: 
#' \itemize{
#' \item{\code{\link{?copy.obj}}}
#' \item{\code{\link{?copy_obj}}}
#' \item{\code{\link{?load.unloaded}}}
#' \item{\code{\link{?load_unloaded}}}
#' \item{\code{\link{?refer.to}}}
#' \item{\code{\link{?refer_to}}}
#' \item{\code{\link{?save.obj}}}
#' \item{\code{\link{?save_image}}}
#' }
#'
#' @section Chapter 3 - Workflow Management: 
#' \itemize{
#' \item{\code{\link{?make.snippet}}}
#' \item{\code{\link{?make_snippet}}}
#' \item{\code{\link{?read.snippet}}}
#' \item{\code{\link{?read_snippet}}}
#' \item{\code{\link{?snippets_toc}}}
#' }
#'
#'
#' @importFrom magrittr %>% %T>% %<>% %$% freduce not
#' @importFrom data.table %between% %ilike% %like% rbindlist last setattr
#' @importFrom stringi %s+%
#' @importFrom utils askYesNo installed.packages
#' @name book.of.workflow
NULL
