# book.of.workflow 0.1.2.1120

- `snippets_toc()`: Added a check for interactivity when `choose = TRUE`

# book.of.workflow 0.1.2.1111

- Documentation updates
- Export of function aliases `read.snippet()` and `make.snippet()`

# book.of.workflow 0.1.2.1110

- Documentation updates only
# book.of.workflow 0.1.2.1110

- Documentation updates only

# book.of.workflow 0.1.2.1000

## Enhancements

- `save_image()`: 
   - Added `svDialogs::okCancelBox` to trigger when argument `safe` is `TRUE`
- `read_snippet()`: 
   - Argument `...` changed to be processed with `rlang::enexprs`
- `snippets_toc()`:
   - Added the `choose` argument
